'use server';

import { cookies  } from "next/headers";
import { createCart, addToCart, getCart, updateCartLine as updateShopifyCartLine, removeFromCart } from "@/lib/shopify/cart";

async function getCartId() {
    const cookieStore = await cookies();
    return cookieStore.get('cartId')?.value ?? cookieStore.get('cartID')?.value;
}

export async function addItemToCart(variantId: string, quantity: number) {
    const cookieStore = await cookies();
    const existingCartId = cookieStore.get('cartId')?.value ?? cookieStore.get('cartID')?.value;

    let cart;

    if(existingCartId) {
        cart = await addToCart(existingCartId, variantId, quantity);
    }else {
        cart = await createCart(variantId, quantity);

        cookieStore.set('cartId', cart.id, {
            httpOnly: true,
            maxAge: 60 * 60 * 24 * 30,
        });
    }
    return cart;
}

export async function getCurrentCart() {
    const cartId = await getCartId();
    return cartId ? getCart(cartId) : null;
}

export async function updateCartLine(lineId: string, quantity: number) {
    const cartId = await getCartId();
    if (!cartId) return null;
    if (quantity <= 0) return removeItemFromCart(lineId);
    return updateShopifyCartLine(cartId, lineId, quantity);
}

export async function removeItemFromCart(lineId: string) {
    const cartId = await getCartId();
    return cartId ? removeFromCart(cartId, lineId) : null;
}