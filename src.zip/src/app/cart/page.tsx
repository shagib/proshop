export { default } from './CartPageContent';
